#!/bin/bash
homedir="$1"
destdir="$2"
cd "$homedir/$destdir" || exit 0
rm -f capture.stdout
capture_file=""
if [ -s capture.pcapng ]; then
    capture_file=capture.pcapng
fi
if [ -n "$capture_file" ]; then
    if command -v tshark >/dev/null 2>&1; then
        tshark -r "$capture_file" -c 1 -V > capture.stdout 2>&1 || rm -f capture.stdout
    elif command -v tcpdump >/dev/null 2>&1; then
        tcpdump -nn -vvv -r "$capture_file" > capture.stdout 2>&1 || rm -f capture.stdout
    fi
fi
