#!/bin/bash
homedir=$1
destdir=$2
TARGET_DIR="$homedir/$destdir/.local/result"

if [ -d "$TARGET_DIR" ]; then
    # Tim tat ca cac timestamp tu cac file .stdout
    timestamps=$(find "$TARGET_DIR" -name "*.stdout.*" | sed -e 's/.*\.stdout\.//' | sort -u)
    
    # Voi moi timestamp, tao ban sao cho cac file cau hinh tinh
    for ts in $timestamps; do
        # Copy squid.conf
        if [ -f "$TARGET_DIR/etc/squid/squid.conf" ]; then
            cp "$TARGET_DIR/etc/squid/squid.conf" "$TARGET_DIR/etc/squid/squid.conf.$ts"
        fi
        # Copy blacklist.txt
        if [ -f "$TARGET_DIR/etc/squid/blacklist.txt" ]; then
            cp "$TARGET_DIR/etc/squid/blacklist.txt" "$TARGET_DIR/etc/squid/blacklist.txt.$ts"
        fi
        # Copy whitelist.txt
        if [ -f "$TARGET_DIR/etc/squid/whitelist.txt" ]; then
            cp "$TARGET_DIR/etc/squid/whitelist.txt" "$TARGET_DIR/etc/squid/whitelist.txt.$ts"
        fi
        # Copy access.log
        if [ -f "$TARGET_DIR/var/log/squid/access.log" ]; then
            mkdir -p "$TARGET_DIR/var/log/squid"
            cp "$TARGET_DIR/var/log/squid/access.log" "$TARGET_DIR/var/log/squid/access.log.$ts"
        fi
    done
fi
