#!/bin/bash
# Convert the student's tcpdump pcap into the legacy text artifact.
homedir="$1"
destdir="$2"
cd "$homedir/$destdir" || exit 0
tcpdump_bin=$(command -v tcpdump || true)
[ -n "$tcpdump_bin" ] || exit 0
if [ -s tcpdump.pcap ]; then
    "$tcpdump_bin" -nn -vvv -r tcpdump.pcap > tcpdump.stdout 2>&1 || true
fi
