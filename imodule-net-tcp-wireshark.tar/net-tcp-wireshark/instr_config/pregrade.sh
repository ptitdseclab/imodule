#!/bin/bash
homedir="$1"
destdir="$2"
cd "$homedir/$destdir" || exit 0
rm -f capture.stdout
tcpdump_bin=$(command -v tcpdump || true)
[ -n "$tcpdump_bin" ] || exit 0
if [ -s tcp-session.pcapng ]; then
    "$tcpdump_bin" -nn -vvv -r tcp-session.pcapng > capture.stdout 2>&1 || rm -f capture.stdout
fi
