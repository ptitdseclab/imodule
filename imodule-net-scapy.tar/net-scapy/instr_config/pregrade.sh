#!/bin/bash
# Build the text evidence from pcap captures, never from a student text log.
homedir="$1"
destdir="$2"
cd "$homedir/$destdir" || exit 0
tcpdump_bin=$(command -v tcpdump || true)
[ -n "$tcpdump_bin" ] || exit 0
if [ -s traffic.pcap ] || [ -s spoof.pcap ]; then
    : > tcpdump.stdout
    for pcap in traffic.pcap spoof.pcap; do
        if [ -s "$pcap" ]; then
            "$tcpdump_bin" -nn -vvv -r "$pcap" >> tcpdump.stdout 2>&1 || true
        fi
    done
fi
