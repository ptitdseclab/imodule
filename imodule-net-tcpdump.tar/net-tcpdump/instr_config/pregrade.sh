#!/bin/bash
# Only tcpdump-readable pcap files are converted into grading artifacts.
homedir="$1"
destdir="$2"
cd "$homedir/$destdir" || exit 0
tcpdump_bin=$(command -v tcpdump || true)
[ -n "$tcpdump_bin" ] || exit 0
for pair in "icmp.pcap icmp.log" "tcp.pcap tcp.log" "udp.pcap udp.log"; do
    set -- $pair
    if [ -s "$1" ]; then
        "$tcpdump_bin" -nn -vvv -r "$1" > "$2" 2>&1 || true
    fi
done
