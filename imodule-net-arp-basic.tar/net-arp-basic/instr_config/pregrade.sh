#!/bin/bash
# Convert a real packet capture into the text artifact used by results.config.
homedir="$1"
destdir="$2"
cd "$homedir/$destdir" || exit 0
tcpdump_bin=$(command -v tcpdump || true)
[ -n "$tcpdump_bin" ] || exit 0
if [ -s arp_catch.pcap ]; then
    "$tcpdump_bin" -nn -vvv -r arp_catch.pcap > arp_catch.stdout 2>&1 || true
fi
