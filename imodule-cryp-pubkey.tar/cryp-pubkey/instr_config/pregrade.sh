#!/bin/bash
: <<'END'
This software was created by United States Government employees at
The Center for Cybersecurity and Cyber Operations (C3O)
at the Naval Postgraduate School NPS.  Please note that within the
United States, copyright protection is not available for any works
created by United States Government employees pursuant to Title 17
United States Code Section 105. This software is in the public
domain and is not subject to copyright.
END

# Run prior to grading a student's lab.  Convert Firefox places.sqlite
# into a text artifact that can be consumed by results.config.

homedir=$1
destdir=$2
cd "$homedir/$destdir" || exit 1

outpath="$PWD/.local/result"
outfile="$outpath/moz_places.txt"
mkdir -p "$outpath"
: > "$outfile"

# Firefox profile names vary by Firefox version (e.g. *.default and
# *.default-release).  Do not assume a particular profile suffix.
# Find every collected places.sqlite and extract its moz_places table.
find "$PWD/.mozilla/firefox" -type f -name 'places.sqlite' -print0 2>/dev/null |
while IFS= read -r -d '' fname; do
    # Checkpoint the WAL when possible so recent history is visible.
    sqlite3 "$fname" 'PRAGMA wal_checkpoint;' >/dev/null 2>&1 || true

    if sqlite3 "$fname" 'SELECT 1 FROM sqlite_master WHERE type="table" AND name="moz_places" LIMIT 1;' 2>/dev/null | grep -q 1; then
        sqlite3 -separator '|' "$fname" 'SELECT * FROM moz_places;' >> "$outfile" 2>/dev/null || true
    fi
done

# Keep the artifact present even when no history exists.  This makes the
# assessment deterministic instead of failing because the file is absent.
exit 0
